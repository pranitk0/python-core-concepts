#Print all elements in a list
my_list = [10, 20, 30, 40, 50]
for item in my_list:
    print(item)
