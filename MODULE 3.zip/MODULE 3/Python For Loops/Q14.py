#Print only vowels in "programming".
text = "programming"
vowels = "aeiou"
for char in text:
    if char in vowels:
        print(char)
