#Loop through a tuple and print items.
my_tuple = (10, 20, 30, 40, 50)
for item in my_tuple:
    print(item)
