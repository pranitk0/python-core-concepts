#Loop through dictionary and print values.
my_dict = {
    "name": "Pranit",
    "age": 23,
    "city": "Mumbai"
}
for value in my_dict.values():
    print(value)
