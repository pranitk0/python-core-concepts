#Use range(2,10,2) to print even numbers.
for i in range(2, 10, 2):
    print(i)
