#Print squares of numbers 1–10.
for i in range(1, 11):
    print(i, "square =", i * i)
