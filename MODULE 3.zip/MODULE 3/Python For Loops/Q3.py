#Print each character in string "Hello".
text = "Hello"
for char in text:
    print(char)
