#Print elements with condition (only numbers > 5)
numbers = [2, 5, 7, 1, 9, 3, 6]
for num in numbers:
    if num > 5:
        print(num)
