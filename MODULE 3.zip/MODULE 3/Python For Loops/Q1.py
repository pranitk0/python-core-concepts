#Print numbers 1 to 10 using for.
for i in range(1, 11):
    print(i)
