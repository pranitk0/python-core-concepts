#Loop through a set and print items
my_set = {10, 20, 30, 40, 50}
for item in my_set:
    print(item)
