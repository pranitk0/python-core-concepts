#Print sum of numbers from 1 to 50.
total = 0
for i in range(1, 51):
    total += i

print("Sum =", total)
