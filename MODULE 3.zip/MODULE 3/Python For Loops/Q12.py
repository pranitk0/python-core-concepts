#Loop through dictionary and print keys
my_dict = {
    "name": "Pranit",
    "age": 20,
    "city": "Rtn"
}
for key in my_dict:
    print(key)
