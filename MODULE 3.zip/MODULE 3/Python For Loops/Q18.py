#Print index and value of list using enumerate().
my_list = ['a', 'b', 'c', 'd']
for index, value in enumerate(my_list):
    print(f"Index: {index}, Value: {value}")
