#Print multiplication table of 7.
for i in range(1, 11):
    print(f"7 x {i} = {7 * i}")
