#Use range(5) to print 0–4.
for i in range(5):
    print(i)
