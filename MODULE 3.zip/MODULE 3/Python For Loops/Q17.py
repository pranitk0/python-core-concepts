#Nested loop: print multiplication table from 1–3
for i in range(1, 4): 
    print(f"Multiplication Table of {i}:")
    for j in range(1, 11): 
        print(f"{i} x {j} = {i * j}")
    print() 
