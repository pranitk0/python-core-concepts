#Print even numbers between 1–20.
for i in range(2, 21, 2):
    print(i)
