#Print product of numbers from 1 to 5.
product = 1
for i in range(1, 6):
    product *= i

print("Product =", product)
