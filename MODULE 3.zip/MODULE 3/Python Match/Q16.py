#Match file extension: .py, .txt, .jpg.
ext = ".txt"
match ext:
    case ".py":
        print("Python file")
    case ".txt":
        print("Text file")
    case ".jpg":
        print("Image file")
    case _:
        print("Unknown file type")
