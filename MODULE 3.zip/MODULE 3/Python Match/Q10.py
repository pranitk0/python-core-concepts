#Match animal and print its sound.
animal = "Cat"

match animal:
    case "Dog":
        print("Bark")
    case "Cat":
        print("Meow")
    case "Cow":
        print("Moo")
    case "Lion":
        print("Roar")
    case _:
        print("Unknown animal")
