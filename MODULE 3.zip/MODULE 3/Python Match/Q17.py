#Match country and print its capital.
country = "India"
match country:
    case "India":
        print("Mumbai")
    case "USA":
        print("Washington, D.C.")
    case "Japan":
        print("Tokyo")
    case "France":
        print("Paris")
    case _:
        print("Unknown country")
