num = 1
if num == 1:
    print("One")
