#Default case: print "Not Found".
item = "Orange"
match item:
    case "Apple":
        print("Fruit")
    case "Carrot":
        print("Vegetable")
    case "Dog":
        print("Animal")
    case _:  # Default case
        print("Not Found")
