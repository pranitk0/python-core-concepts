#Match vehicle type and print "Car", "Bike", etc.
vehicle = 3
match vehicle:
    case 1:
        print("Car")
    case 2:
        print("Bike")
    case 3:
        print("Bus")
    case 4:
        print("Truck")
    case _:
        print("Unknown vehicle")
