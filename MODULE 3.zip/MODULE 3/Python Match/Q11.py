#Match 0 and print "Zero", else print "Other".
num = 5
match num:
    case 0:
        print("Zero")
    case _:
        print("Other")
