#Match number range 6–10 and print big number.
num = 4
match num:
    case n if 6 <= n <= 10:
        print("Big number")
    case _:
        print("Not a big number")
