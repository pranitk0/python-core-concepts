#Match user role: "Admin", "User", "Guest".
role = "Guest"
match role:
    case "Admin":
        print("Full access")
    case "User":
        print("Limited access")
    case "Guest":
        print("Read-only access")
    case _:
        print("Invalid role")
