#Match traffic light color (Red, Yellow, Green).
color = "Green"

match color:
    case "Red":
        print("Stop")
    case "Yellow":
        print("Get Ready")
    case "Green":
        print("Go")
    case _:
        print("Invalid color")
