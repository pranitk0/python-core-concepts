#Match even/odd using match-case.
num = 7
match num % 2:
    case 0:
        print("Even")
    case 1:
        print("Odd")
