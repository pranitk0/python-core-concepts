#Match vowels (a, e, i, o, u).
ch = input("Enter a character: ").lower()
match ch:
    case 'a' | 'e' | 'i' | 'o' | 'u':
        print("Vowel")
    case _:
        print("Not a vowel")
