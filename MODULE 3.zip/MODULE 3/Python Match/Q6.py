#Match fruit name and print its color.
fruit = "Banana"
match fruit:
    case "Apple":
        print("Red")
    case "Banana":
        print("Yellow")
    case "Orange":
        print("Orange")
    case "Grapes":
        print("Green")
    case _:
        print("Unknown fruit")
