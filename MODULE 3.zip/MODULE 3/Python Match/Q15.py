#Match operating system: "Windows", "Linux", "Mac".
os = "Mac"
match os:
    case "Windows":
        print("Microsoft Windows")
    case "Linux":
        print("Linux OS")
    case "Mac":
        print("MacOS")
    case _:
        print("Unknown OS")
