#Match number range 1–5 and print small number.
num = 7
match num:
    case n if 1 <= n <= 5:
        print("Small number")
    case _:
        print("Not a small number")
