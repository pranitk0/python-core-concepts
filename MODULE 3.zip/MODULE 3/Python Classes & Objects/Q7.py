#Print object info using a method inside class
class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def print_info(self):
        print("Name:", self.name)
        print("Marks:", self.marks)
s1 = Student("Amit", 85)
s2 = Student("Neha", 92)

s1.print_info()
print("-----")
s2.print_info()
