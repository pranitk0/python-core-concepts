#Create objects dynamically using input from user.

class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

students = []

n = int(input("Enter number of students: "))

for i in range(n):
    print(f"\nEnter details for student {i+1}")
    name = input("Name: ")
    marks = int(input("Marks: "))

    s = Student(name, marks)
    students.append(s)

print("\nStudent List:")
for student in students:
    print("Name:", student.name, "| Marks:", student.marks)
