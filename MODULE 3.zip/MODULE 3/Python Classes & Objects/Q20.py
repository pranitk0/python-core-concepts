#Destroy an object and print message in __del__.

class Person:
    def __init__(self, name):
        self.name = name
        print(f"{self.name} has been created.")

    def __del__(self):
        print(f"{self.name} is being destroyed.")

p1 = Person("Pranit")
p2 = Person("Raj")
del p1  
print(p2.name)  
