#Use __init__ to assign default values

class Book:
    def __init__(self, title="Unknown Title", author="Unknown Author"):
        self.title = title
        self.author = author

book1 = Book()
book2 = Book("Chhava")
book3 = Book("Atomic Habits", "James Clear")

print(book1.title, "-", book1.author)
print(book2.title, "-", book2.author)
print(book3.title, "-", book3.author)
