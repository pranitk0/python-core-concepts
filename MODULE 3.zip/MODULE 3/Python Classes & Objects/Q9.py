#Compare attributes of two objects.

class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

s1 = Student("Pranit", 78)
s2 = Student("Raj", 85)

if s1.marks > s2.marks:
    print(s1.name, "has higher marks")
elif s1.marks < s2.marks:
    print(s2.name, "has higher marks")
else:
    print("Both have equal marks")
