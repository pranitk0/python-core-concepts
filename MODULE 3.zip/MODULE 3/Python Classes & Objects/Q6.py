#Show how to store objects in a list

class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

# Create objects
s1 = Student("Pranit", 75)
s2 = Student("Raj", 82)
s3 = Student("Shubh", 68)

students = [s1, s2, s3]

for student in students:
    print(student.name, student.marks)
