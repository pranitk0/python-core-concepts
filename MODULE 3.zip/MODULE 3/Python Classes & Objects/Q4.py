#Modify attribute values after object creation

class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age

dog1 = Dog("Buddy", 3)
print(dog1.name,dog1.age)

dog1.name="puppy"
dog1.age=2
print(dog1.name,dog1.age)