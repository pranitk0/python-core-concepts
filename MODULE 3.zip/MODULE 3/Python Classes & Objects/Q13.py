# Print a list of books using objects

class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author

book1 = Book("The Alchemist", "Paulo Coelho")
book2 = Book("Harry Potter", "J.K. Rowling")
book3 = Book("Atomic Habits", "James Clear")

books = [book1, book2, book3]

for book in books:
    print("Title:", book.title, "| Author:", book.author)
