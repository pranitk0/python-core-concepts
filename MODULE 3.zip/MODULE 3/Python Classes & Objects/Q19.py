#Show that objects can call each other’s methods.

class Person:
    def __init__(self, name):
        self.name = name

    def greet(self):
        print(f"Hello, my name is {self.name}!")

    def greet_friend(self, friend):
        print(f"{self.name} is greeting {friend.name}")
        friend.greet()  

pranit = Person("Pranit")
raj = Person("Raj")

pranit.greet()  
raj.greet()    

pranit.greet_friend(raj)

raj.greet_friend(pranit)



