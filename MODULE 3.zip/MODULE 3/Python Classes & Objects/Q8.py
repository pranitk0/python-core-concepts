#Create a method to calculate dog’s age in human years

class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age   # age in dog years

    def human_years(self):
        return self.age * 7

dog1 = Dog("Buddy", 3)
dog2 = Dog("Rocky", 5)

print(dog1.name, "human age:", dog1.human_years())
print(dog2.name, "human age:", dog2.human_years())
