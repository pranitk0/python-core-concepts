#Create a class Book with title and author

class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author

book1 = Book("Atomic Habits", "james Clear")
book2 = Book("Harry Potter", "J.K. Rowling")

print(book1.title, "-", book1.author)
print(book2.title, "-", book2.author)
