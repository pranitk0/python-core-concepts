#Create a class with a counter to track number of objects created.

class Person:
    count = 0

    def __init__(self, name):
        self.name = name      
        Person.count += 1     
p1 = Person("Alice")
p2 = Person("Bob")
p3 = Person("Charlie")

print("Number of Person objects created:", Person.count)  # 3
