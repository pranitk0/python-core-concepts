#Demonstrate difference between class attribute and instance attribute
 
# Define a class
class Car:
    wheels = 4

    def __init__(self, brand, color):
       
        self.brand = brand
        self.color = color

car1 = Car("Toyota", "Red")
car2 = Car("Honda", "Blue")

print("Car1 wheels:", car1.wheels) 
print("Car2 wheels:", car2.wheels)  

print("Car1 brand:", car1.brand)    
print("Car1 color:", car1.color)    
print("Car2 brand:", car2.brand)    
print("Car2 color:", car2.color)    

car1.color = "Black"
print("Car1 new color:", car1.color) 
print("Car2 color remains:", car2.color)  

print("Car1 wheels after change:", car1.wheels)  # 6
print("Car2 wheels after change:", car2.wheels)  # 6
