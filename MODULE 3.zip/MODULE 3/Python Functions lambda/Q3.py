#Write a lambda function to return the square of a number.
square = lambda x: x ** 2

print(square(5))
print(square(10))
