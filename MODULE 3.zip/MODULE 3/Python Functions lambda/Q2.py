#Write a lambda function to multiply two numbers
multiply = lambda x, y: x * y

print(multiply(5, 3))
print(multiply(7, 4))
