#Write a lambda function to check if a number is even.
is_even = lambda x: x % 2 == 0

print(is_even(4))  
print(is_even(7))  
