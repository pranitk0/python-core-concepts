#Write a lambda function that returns the length of a string.
string_length = lambda s: len(s)

print(string_length("Hello"))
print(string_length("Python"))
