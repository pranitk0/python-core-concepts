#Use a lambda with sorted() to sort a list of tuples by the second value.
data = [(1, 5), (2, 2), (3, 8), (4, 1)]
sorted_data = sorted(data, key=lambda x: x[1])
print(sorted_data)
