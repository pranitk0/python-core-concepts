#Use a lambda with filter() to return numbers greater than 10 from a list.
numbers = [5, 12, 7, 18, 3, 25, 10]

greater_than_10 = list(filter(lambda x: x > 10, numbers))
print(greater_than_10)
