#Write a lambda function to add 10 to a number
add_ten = lambda x: x + 10

print(add_ten(5))
print(add_ten(20))
