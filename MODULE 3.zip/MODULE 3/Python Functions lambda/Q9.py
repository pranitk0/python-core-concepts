#Write a lambda function that returns the first character of a string.
first_char = lambda s: s[0]

print(first_char("Hello"))
print(first_char("Python"))
