#Write a lambda function that joins first and last name.
full_name = lambda first, last: first + " " + last

print(full_name("Pranit", "Kamble"))