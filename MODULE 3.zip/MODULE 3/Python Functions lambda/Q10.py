#Write a lambda function that converts string into uppercase.
to_upper = lambda s: s.upper()

print(to_upper("hello"))
print(to_upper("Python"))
