#Create a lambda function that adds three numbers together.

add_three = lambda a, b, c: a + b + c

print(add_three(5, 10, 15))
print(add_three(1, 2, 3))
