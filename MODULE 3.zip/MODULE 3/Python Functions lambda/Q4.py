#Write a lambda function to return the cube of a number
cube = lambda x: x ** 3
print(cube(3))
print(cube(5))
