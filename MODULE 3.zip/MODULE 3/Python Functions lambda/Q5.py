#Write a lambda function to find the maximum of two numbers
maximum = lambda a, b: a if a > b else b

print(maximum(5, 10))
print(maximum(20, 15))
