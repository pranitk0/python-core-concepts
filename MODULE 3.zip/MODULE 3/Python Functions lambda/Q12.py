#Use a lambda with map() to convert a list of strings into uppercase
words = ["hello", "world", "python"]

uppercase_words = list(map(lambda s: s.upper(), words))
print(uppercase_words)
