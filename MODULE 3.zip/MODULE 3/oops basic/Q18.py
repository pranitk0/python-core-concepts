#Create a list of objects and access their attributes.
class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks
s1 = Student("Pranit", 85)
s2 = Student("Amit", 90)
s3 = Student("Raj", 78)

students = [s1, s2, s3]
for student in students:
    print(student.name, student.marks)
