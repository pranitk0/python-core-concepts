#Q8.Create a class Student with name and roll number
class Student:
    def __init__(self, name, roll_no):
        self.name = name
        self.roll_no = roll_no
s1 = Student("Pranit", 101)
print("Name:", s1.name)
print("Roll Number:", s1.roll_no)

print()

#Q9.
class Circle:
    def __init__(self, radius):
        self.radius = radius
    def area(self):
        return 3.14 * self.radius * self.radius
c1 = Circle(7)
print("Area of Circle:", c1.area())

print()

#Q10.Add a method to Circle to calculate circumference
class Circle:
    def __init__(self, radius):
        self.radius = radius
    def area(self):
        return 3.14 * self.radius * self.radius
    def circumference(self):
        return 2 * 3.14 * self.radius
c2 = Circle(7)
print("Area:", c2.area())
print("Circumference:", c2.circumference())

print()

#Q11.Create a class with both class variables and instance variable
class Student:
    school_name = "ABC School"
    def __init__(self, name, roll_no):
        self.name = name
        self.roll_no = roll_no
    def display(self):
        print("Name:", self.name)
        print("Roll No:", self.roll_no)
        print("School:", Student.school_name)
s1 = Student("Pranit", 101)
s2 = Student("Rahul", 102)
s1.display()
print()
s2.display()

print()
 
#Q12. Create a method that updates an attribute value.
class Student:
    def __init__(self, name, roll_no):
        self.name = name
        self.roll_no = roll_no
    def update_name(self, new_name):
        self.name = new_name
    def display(self):
        print("Name:", self.name)
        print("Roll No:", self.roll_no)
s1 = Student("Pranit", 101)
s1.display()
s1.update_name("Raj")
print("\nAfter update:")
s1.display()

