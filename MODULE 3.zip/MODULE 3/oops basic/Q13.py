#Use __str__ to return a string when printing an object
class person():
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def os(self):
        return f"My name is {self.name} and i am {self.age} years old"  
p1 = person("pranit",20)
print(p1.os())        
        