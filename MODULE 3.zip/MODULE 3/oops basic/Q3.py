#Q3.Add a method drive() that prints “Car is driving”
class Car:
    def __init__(self, brand, color):
        self.brand = brand
        self.color = color
    def drive(self):
        print("Car is driving")
my_car = Car("Toyota", "black")
print(my_car.brand,my_car.color)
my_car.drive()