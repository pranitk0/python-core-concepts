#. Demonstrate how multiple objects can have different attributes
class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

s1 = Student("Pranit", 85)
s2 = Student("Amit", 92)
s3 = Student("Riya", 78)
print(s1.name, s1.marks)
print(s2.name, s2.marks)
print(s3.name, s3.marks)
