
class BankAccount:
    def __init__(self, account_holder, balance):
        self.account_holder = account_holder  
        self.__balance = balance              

    def deposit(self, amount):
        self.__balance += amount

    def balance(self):
        return self.__balance
acc1 = BankAccount("Pranit", 1000)
acc1.deposit(500)
print("Balance:", acc1.balance())
