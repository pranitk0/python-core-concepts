#Q10.Add a method to Circle to calculate circumference
class Circle:
    def __init__(self, radius):
        self.radius = radius
    def area(self):
        return 3.14 * self.radius * self.radius
    def circumference(self):
        return 2 * 3.14 * self.radius
c2 = Circle(7)
print("Area:", c2.area())
print("Circumference:", c2.circumference())

print()