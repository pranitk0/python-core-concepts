#Q1 Create a class Car with attributes brand and color.
class Car:
    pass
my_car = Car()
my_car.brand = "Honda"
my_car.color = "Blue"
print(my_car.brand)
print(my_car.color)
