#Q4.Create multiple objects of a class
class Car:
    def __init__(self, brand, color):
        self.brand = brand
        self.color = color
car1 = Car("Honda", "Blue")
car2 = Car("Toyota", "Red")
car3 = Car("BMW", "Black")
print(car1.brand, car1.color)
print(car2.brand, car2.color)
print(car3.brand, car3.color)        