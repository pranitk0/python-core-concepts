#Q6.Print object attributes using self
class Car:
    def __init__(self, brand, color):
        self.brand = brand
        self.color = color
    def drive(self):
        print("Car is driving")
my_car = Car("Mercedes", "Red")
print(my_car.brand)
print(my_car.color)