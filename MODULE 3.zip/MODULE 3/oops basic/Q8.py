#Q8.Create a class Student with name and roll number
class Student:
    def __init__(self, name, roll_no):
        self.name = name
        self.roll_no = roll_no
s1 = Student("Pranit", 101)
print("Name:", s1.name)
print("Roll Number:", s1.roll_no)

print()