#Create a class with a default attribute value.
class person():
    def __init__(self,name,age=20):
        self.name=name
        self.age=age
 
p1 = person("pranit")
p2 = person("raj",22)
print(p1.name,p1.age)
print(p2.name,p2.age)
