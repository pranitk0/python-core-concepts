#Q2.Create an object of the class Car
class Car:
    pass
my_car = Car()
my_car.brand = "Toyota"
my_car.color = "black"
print(my_car.brand)
print(my_car.color)
