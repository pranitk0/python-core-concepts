#Q12. Create a method that updates an attribute value.
class Student:
    def __init__(self, name, roll_no):
        self.name = name
        self.roll_no = roll_no
    def update_name(self, new_name):
        self.name = new_name
    def display(self):
        print("Name:", self.name)
        print("Roll No:", self.roll_no)
s1 = Student("Pranit", 101)
s1.display()
s1.update_name("Raj")
print("\nAfter update:")
s1.display()

