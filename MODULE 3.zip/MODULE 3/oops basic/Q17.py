#Create a class where one method calls another method.
class Calculator:
    def add(self, a, b):
        return a + b

    def sum(self, a, b):
        result = self.add(a, b)  
        print("Sum is:", result)
c1 = Calculator()
c1.sum(10, 20)
