#Create a method to return the description of the car

class Car:
    def __init__(self, brand, color, year):
        self.brand = brand
        self.color = color
        self.year = year

    def description(self):
        return f"This car is a {self.color} {self.brand} from {self.year}."

car1 = Car("Toyota", "Red", 2020)
car2 = Car("Honda", "Blue", 2018)

print(car1.description())
print(car2.description())
