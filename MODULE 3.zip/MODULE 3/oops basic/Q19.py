#Create a method that checks if a student passed (marks ≥ 40).

class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def is_passed(self):
        if self.marks >= 40:
            return "Passed"
        else:
            return "Failed"
s1 = Student("Pranit", 55)
s2 = Student("Amit", 32)

print(s1.name, ":", s1.is_passed())
print(s2.name,":",s2.is_passed())
