#Q5.Initialize attributes using __init__.
class Car:
    def __init__(self, brand, color):
        self.brand = brand
        self.color = color
car1 = Car("BMW", "Black")
print(car1.brand, car1.color)
