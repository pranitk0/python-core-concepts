
#Q11.Create a class with both class variables and instance variable
class Student:
    school_name = "ABC School"
    def __init__(self, name, roll_no):
        self.name = name
        self.roll_no = roll_no
    def display(self):
        print("Name:", self.name)
        print("Roll No:", self.roll_no)
        print("School:", Student.school_name)
s1 = Student("Pranit", 101)
s2 = Student("Rahul", 102)
s1.display()
print()
s2.display()

print()