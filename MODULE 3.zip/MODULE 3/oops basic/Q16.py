# Create a method inside a class that takes an argument.
class Calculator:
    def add(self, number):
        return number + 10
c1 = Calculator()
result = c1.add(5)
print(result)
