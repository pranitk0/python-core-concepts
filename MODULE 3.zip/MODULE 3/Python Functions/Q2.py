#Create function to add two numbers
def add_numbers(a, b):
    return a + b
result = add_numbers(5, 3)
print("Sum =", result)
