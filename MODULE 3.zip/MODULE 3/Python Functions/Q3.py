# Create function to divide two numbers
def divide_numbers(a, b):
    if b == 0:
        return "Error: Division by zero is not allowed"
    return a / b
result = divide_numbers(10, 2)
print("Result =", result)
