#Create function to return square of number
def square(number):
    return number * number
result = square(5)
print("Square =", result)
