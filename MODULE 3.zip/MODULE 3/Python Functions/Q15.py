#Create function with multiple parameters.

def introduce(name, age, city):
    print(f"My name is {name}, I am {age} years old, and I live in {city}.")
introduce("Pranit", 20, "Mumbai")
introduce("Raj", 30, "Pune")
