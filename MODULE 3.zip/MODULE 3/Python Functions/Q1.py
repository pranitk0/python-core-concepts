#Create function to print "Hello World"
def hello():
    print("Hello World")
hello()
