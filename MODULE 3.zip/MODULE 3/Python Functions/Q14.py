# Create function with default parameter.

def greet(name="Guest"):
    print("Hello,", name)

greet("Pranit") 
greet()         
