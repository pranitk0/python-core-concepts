#Create function that reverses a string.
def reverse_string(text):
    reversed_text = text[::-1] 
    return reversed_text
result = reverse_string("Hello")
print("Reversed string:", result)
