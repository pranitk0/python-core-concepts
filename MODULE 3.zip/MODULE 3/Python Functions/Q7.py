#Create function that prints your name.
def print_name():
    print("Pranit Kamble")
print_name()
