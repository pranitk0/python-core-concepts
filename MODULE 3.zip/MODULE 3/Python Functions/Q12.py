# Create function that returns max of 3 numbers.
def max_of_three(a, b, c):
    if a >= b and a >= c:
        return a
    elif b >= a and b >= c:
        return b
    else:
        return c
result = max_of_three(5, 10, 7)
print("Maximum number is:", result)
