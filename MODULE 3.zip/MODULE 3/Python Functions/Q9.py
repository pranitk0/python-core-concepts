#Create function that counts vowels in a string
def count_vowels(text):
    vowels = "aeiouAEIOU"  
    count = 0
    for char in text:
        if char in vowels:
            count += 1
    print("Number of vowels:", count)

count_vowels("Programming")
count_vowels("Hello World")
