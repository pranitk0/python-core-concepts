#Create function that takes a string and prints length
def print_length(text):
    print("Length of the string is:", len(text))
print_length("Hello World")
print_length("Python")
