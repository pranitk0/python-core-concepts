#Create function to return cube of number.
def cube(number):
    return number ** 3 
result = cube(4)
print("Cube =", result)
