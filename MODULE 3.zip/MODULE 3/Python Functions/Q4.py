#Create function to check if number is even
def check_even(number):
    if number % 2 == 0:
        print(number, "is even")
    else:
        print(number, "is odd")
check_even(8)
check_even(5)
