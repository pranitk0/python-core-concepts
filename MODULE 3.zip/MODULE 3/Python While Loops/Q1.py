#Print numbers 1 to 10 using while.
i = 1
while i <= 10:
    print(i)
    i += 1
