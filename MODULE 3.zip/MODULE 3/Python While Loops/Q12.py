#Print digits of number 1234 separately.
num = 1234
while num > 0:
    digit = num % 10
    print(digit)
    num //= 10
