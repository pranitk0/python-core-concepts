#Print only numbers divisible by 4 up to 40.
for i in range(4, 41, 4):
    print(i)
