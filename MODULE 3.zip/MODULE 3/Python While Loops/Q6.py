#Print sum of first 10 natural numbers.
i = 1
sum = 0
while i <= 10:
    sum += i
    i += 1
print(sum)
