#Reverse number 12345 using while.
num = 12345
reversed_num = 0
while num > 0:
    digit = num % 10          
    reversed_num = reversed_num * 10 + digit  
    num = num // 10         
print("Reversed Number:", reversed_num)
