#Print first 5 multiples of 3.
i = 1
while i <= 5:
    print(3 * i)
    i += 1
