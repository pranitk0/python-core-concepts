#Print factorial of 5 using while.
num = 5
fact = 1
while num > 0:
    fact *= num
    num -= 1
print("Factorial of 5 is:", fact)
