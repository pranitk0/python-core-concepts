#Print multiplication table of 5.
i = 1
while i <= 10:
    print(5 * i)
    i += 1
