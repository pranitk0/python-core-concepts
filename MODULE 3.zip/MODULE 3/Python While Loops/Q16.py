#Find sum of digits of number 567.
for i in range(1, 41):
    if i % 4 == 0:
        print(i)
