# Loop until number reaches 100

num = 1
while num <= 100:  
    print(num)
    num += 1      
