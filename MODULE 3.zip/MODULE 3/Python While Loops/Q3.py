#Print odd numbers from 1 to 20.
i = 1
while i <= 20:
    print(i)
    i += 2
