#Print "Hello" 5 times.
i = 1
while i <= 5:
    print("hello")
    i += 1