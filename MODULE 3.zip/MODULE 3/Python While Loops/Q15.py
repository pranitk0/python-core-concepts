#Print characters of string "Python" one by one.
text = "Python"
for char in text:
    print(char)
