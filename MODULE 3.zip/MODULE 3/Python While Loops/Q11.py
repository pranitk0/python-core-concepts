#Keep asking for input until user enters "exit".
while True:
    user_input = input("Enter something (type 'exit' to stop): ")
    if user_input == "exit":
        break
