#Find product of first 5 natural numbers.
product = 1
for i in range(1, 6):
    product *= i
print(product)
