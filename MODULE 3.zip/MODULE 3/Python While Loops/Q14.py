#Print first 10 Fibonacci numbers.
n = 10
a, b = 0, 1

for i in range(n):
    print(a)
    a, b = a, b + a
