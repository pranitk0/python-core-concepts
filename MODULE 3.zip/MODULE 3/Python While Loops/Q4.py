#Print numbers in reverse from 10 to 1.
i = 10
while i >= 1:
    print(i)
    i -= 1
