#. Use range with max() to find the largest number in a range 50–500

largest = max(range(50, 501))  
print("Largest number in the range is:", largest)
