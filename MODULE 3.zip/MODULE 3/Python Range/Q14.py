# Use range to print numbers in reverse from 20 to 1.
for i in range(20, 0, -1):  
    print(i)
