#Create a range that starts at 0 and ends before 20 with step 2.
numbers = range(0, 20, 2) 
for num in numbers:
    print(num)
