#Create a range of numbers from -10 to -1.
numbers = range(-10, 0)  
for num in numbers:
    print(num)
