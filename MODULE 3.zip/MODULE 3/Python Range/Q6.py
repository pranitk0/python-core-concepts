#Convert a range of numbers (0 to 5) into a list.
numbers = list(range(6))  
print(numbers)
