#Create a range of odd numbers between 1 and 19.
odd_numbers = range(1, 20, 2) 
for num in odd_numbers:
    print(num)
