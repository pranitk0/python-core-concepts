# Use range to print all numbers divisible by 7 up to 100
for i in range(7, 101, 7): 
    print(i)
