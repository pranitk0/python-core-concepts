#Create a range and find its length using len().


numbers = range(5, 21)  
length = len(numbers)
print("Length of the range:", length)
