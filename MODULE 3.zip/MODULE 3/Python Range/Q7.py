#Print numbers from 100 down to 50 using range.
for num in range(100, 49, -1): 
    print(num)
