#Create a range of multiples of 3 from 3 to 30
multiples_of_3 = range(3, 31, 3)  
for num in multiples_of_3:
    print(num)
