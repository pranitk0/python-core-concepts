#Create a range of even numbers between 2 and 20.
even_numbers = range(2, 21, 2) 
for num in even_numbers:
    print(num)
