#Use range with sum() to calculate the sum of numbers 1–100.

total = sum(range(1, 101)) 
print("Sum of numbers from 1 to 100 is:", total)
