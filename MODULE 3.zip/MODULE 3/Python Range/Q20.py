#Write a program to take input n and generate a range from 1 to n.

n = int(input("Enter a number: "))
for i in range(1, n + 1):
    print(i)
