#Create a range of numbers from 0 to 9.
numbers = range(10)
for num in numbers:
    print(num)
