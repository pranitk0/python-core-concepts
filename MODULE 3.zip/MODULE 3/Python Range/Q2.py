#Create a range of numbers from 5 to 15.
numbers = range(5, 16) 
for num in numbers:
    print(num)
