#Use a range to generate numbers from 10 to 50 with step size 5.
numbers = range(10, 51, 5) 
for num in numbers:
    print(num)
