#Create an array of integers from 1 to 5.

arr = [1, 2, 3, 4, 5]
print(arr)
