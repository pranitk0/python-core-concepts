#Create a 2D array (list of lists) and access one element.

matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

element = matrix[1][2] 
print("The accessed element is:", element)
