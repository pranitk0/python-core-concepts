#Use a loop to calculate the sum of all array elements.

arr = [1, 2, 3, 4, 5]
total = 0

for element in arr:
    total += element  
print("Sum of array elements:", total)
