# Flatten a 2D array into a 1D array using loops

# Original 2D array
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

flattened = []

for row in matrix:
    for element in row:
        flattened.append(element)

print("Flattened 1D array:", flattened)
