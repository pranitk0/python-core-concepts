#Use a loop to find the maximum value in an array.

arr = [3, 7, 1, 9, 4]
max_value = arr[0]

for element in arr:
    if element > max_value:
        max_value = element 
print("Maximum value in the array:", max_value)
