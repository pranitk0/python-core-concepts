#Append a new element to an array

arr = [1, 2, 3, 4, 5]
arr.append(6)
print(arr)
