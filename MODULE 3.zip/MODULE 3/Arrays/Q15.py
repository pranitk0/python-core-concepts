# Check if a given element exists in an array

arr = [1, 2, 3, 4, 5]

element = 3
if element in arr:
    print(f"{element} exists in the array.")
else:
    print(f"{element} does not exist in the array.")
