#Loop through an array and print each elemen
arr = [1, 2, 3, 4, 5]
for element in arr:
    print(element)
