#Count how many times a number occurs in an array.

arr = [1, 2, 3, 2, 4, 2, 5]
num_to_count = 2
count = 0

for element in arr:
    if element == num_to_count:
        count += 1

print(f"The number {num_to_count} occurs {count} times in the array.")
