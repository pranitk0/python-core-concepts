#Remove the last element from an array
arr = [1, 2, 3, 4, 5]
arr.pop()
print(arr)
