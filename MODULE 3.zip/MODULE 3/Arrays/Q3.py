#Change the second element of an array

arr = [1, 2, 3, 4, 5]
arr[2]=6
print(arr)
