#Insert a new element at position 2 in an 

arr = [1, 2, 3, 4, 5]
arr.insert(2, 10)
print(arr)
