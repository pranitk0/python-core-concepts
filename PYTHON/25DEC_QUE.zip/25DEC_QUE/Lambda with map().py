numbers = [10, 20, 30, 40]
result = list(map(lambda x: x + 5, numbers))
print(result)
