result = lambda marks: "Pass" if marks >= 40 else "Fail"
print(result(75)) 
print(result(40))   
print(result(28))   