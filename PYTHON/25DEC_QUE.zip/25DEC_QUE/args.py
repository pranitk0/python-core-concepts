def find_max(*args):
    return max(args)
print(find_max(10, 25, 40, 18))   
print(find_max(3, 7))               
