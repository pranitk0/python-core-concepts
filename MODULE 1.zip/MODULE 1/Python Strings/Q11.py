#Check if "a" exists in string "apple".

text = "apple"
print("a" in text)
