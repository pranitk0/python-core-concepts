#Print last character of a string.
text = "Python"
print(text[0])
