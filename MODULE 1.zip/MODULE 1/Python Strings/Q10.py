#Join a list of words into one string.

words = ["Python", "is", "fun"]
joined_string = " ".join(words)
print(joined_string)
