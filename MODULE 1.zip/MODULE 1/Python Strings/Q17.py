#Concatenate two strings.
fname="pranit"
lname="kamble"
concatenate=fname+" "+lname
print(concatenate)