#Check if string ends with "on".
text = "Python"
print(text.endswith("on"))
