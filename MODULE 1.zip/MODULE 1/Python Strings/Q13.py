#Find index of "o" in "Hello World".
text = "Hello World"
index_o = text.index("o")
print(index_o)
