#Slice first 3 characters of a string.
text = "Python"
print(text[:3])
