text = " Python "
text = text.strip()
print(text)
