# Storing name in a string
name = "Pranit"
print(name)
