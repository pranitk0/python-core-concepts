#Print first character of a string.
text = "Python"
print(text[0])
