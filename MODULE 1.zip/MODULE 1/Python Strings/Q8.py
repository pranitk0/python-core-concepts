#10. Replace "Hello" with "Hi" in a string.
text = "Hello World"
new_text = text.replace("Hello", "Hi")
print(new_text)
