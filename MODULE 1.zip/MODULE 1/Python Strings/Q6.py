#Convert string to uppercase.
text = "python"
print(text.upper())
