#Repeat string "Hi" 5 times.
print("hii \n"*5)