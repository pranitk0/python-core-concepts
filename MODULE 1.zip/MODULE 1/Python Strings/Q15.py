text = "Python"
print(text.startswith("Py"))
