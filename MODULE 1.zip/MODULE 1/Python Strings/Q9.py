sentence = "Python is easy"
words = sentence.split()
print(words)
