#Count how many times "a" appears in "banana".
text = "banana"
a = text.count("a")
print(a)
