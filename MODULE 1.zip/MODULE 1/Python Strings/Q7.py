#Capitalize the first letter of a string.
text = "python"
print(text.capitalize())
