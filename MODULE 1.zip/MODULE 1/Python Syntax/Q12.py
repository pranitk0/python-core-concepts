#Check what happens if you forget colons : in if-statement.
#SyntaxError: expected ':'
