#Correct the syntax: Print("Hello world").
print("hello world")