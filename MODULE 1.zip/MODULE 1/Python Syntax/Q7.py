#Add comments to a Python program that prints your age.
print("age: 20")