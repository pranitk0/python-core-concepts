#Write a correct code with multiple spaces.

x    =    5
y    =    10
sum    =    x    +    y
print("Sum:", sum)
