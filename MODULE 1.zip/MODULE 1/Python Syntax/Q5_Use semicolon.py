print("Hello"); print("World")
