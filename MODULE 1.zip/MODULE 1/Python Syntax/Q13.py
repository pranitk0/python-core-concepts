# Program with two empty lines

print("Line 1")

print("Line 2")
