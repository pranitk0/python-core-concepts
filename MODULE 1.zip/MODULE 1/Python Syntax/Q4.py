'''Write a program with proper indentation.
Correct this code:
if True
print("Yes")'''

if True:
    print("yes")