#Write a statement that doesn’t give an error: print("Hello"
print("Hello")