#Write a program that prints "Done" at the end of every block.

# Example of multiple blocks

print("Starting Block 1")
print("Done")

print("Starting Block 2")
print("Done")
