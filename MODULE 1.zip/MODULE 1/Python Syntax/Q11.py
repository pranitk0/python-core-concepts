#Write a program that prints "Good Morning" with correct indentation.

def gm():
    print("Good Morning")

gm()
