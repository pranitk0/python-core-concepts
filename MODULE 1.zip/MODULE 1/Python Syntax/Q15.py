#Write a valid Python program with two lines only.

# Line 1
print("Hello")

# Line 2
print("Python")
