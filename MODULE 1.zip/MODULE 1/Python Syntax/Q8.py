# Multiple statements in one line using semicolon
print("Hello"); print("Python"); print("2025")
