#Write a single-line Python program to print your favorite fruit.
print("favorite fruit: mango")