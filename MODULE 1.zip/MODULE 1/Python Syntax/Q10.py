#Fix this: if 5>2 print("Bigger")

if 5 > 2:
    print("Bigger")