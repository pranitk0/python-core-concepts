#Store your favorite subject in a variable.

favorite_subject = "science"
print(favorite_subject)
