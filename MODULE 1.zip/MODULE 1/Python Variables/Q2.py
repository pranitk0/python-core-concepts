#Store your age in a variable and print it

my_age = 20
print(my_age)
