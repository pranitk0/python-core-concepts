#Swap two variables (a=10, b=20).

a = 10
b = 20

a, b = b, a

print("a =", a)
print("b =", b)
