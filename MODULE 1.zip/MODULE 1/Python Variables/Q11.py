#Create a variable with uppercase letters.

NAME = "Pranit"
print(NAME)
