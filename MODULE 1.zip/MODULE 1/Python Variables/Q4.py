#Change the value of a variable and print before and after

x = 10
print("Before changing:", x)

x = 20
print("After changing:", x)
