#Create variable without assigning and assign later.

x = None       
print(x)

x = 25
print(x)
