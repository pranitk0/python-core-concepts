#Create a variable with an underscore in its name.

# Variable with an underscore in its name
user_name = "Pranit"
print(user_name)
