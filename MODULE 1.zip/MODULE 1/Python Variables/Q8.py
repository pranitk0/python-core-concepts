# Assigning multiple values in one line
x, y, z = 5, 10, 15

print(x)
print(y)
print(z)
