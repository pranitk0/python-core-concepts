#Use variables inside a print statement.
name = "Pranit"
age = 20

print("Name:", name, "Age:", age)
