#Assign the same value to 3 variables in one line.

a = b = c = 10

print(a)
print(b)
print(c)
