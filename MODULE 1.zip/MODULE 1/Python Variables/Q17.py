#Using descriptive variable names

student_name = "Pranit"
student_age = 20
course_name = "Python Programming"

print(student_name)
print(student_age)
print(course_name)
