#Store integer, float, and string in three variables and print them.

number = 10        
price = 99.5       
name = "Pranit"  

print(number)
print(price)
print(name)
