name="pranit"
print(name)