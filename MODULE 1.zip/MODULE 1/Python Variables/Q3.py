#Store 3 numbers in variables and print their sum.

num1 = 5
num2 = 10
num3 = 15

sum = num1 + num2 + num3
print(sum)
