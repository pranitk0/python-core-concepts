#Create variables for city and country. Print them together.

city = "Ratnagiri"
country = "India"

print(city, country)
