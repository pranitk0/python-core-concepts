#Reassign variable with new data type.

x = 10          
print(type(x))

x = "Python"    
print(type(x))
