#Store float number in a variable and print it.
price = 1.1
print(price)
