# Storing a boolean value in a variable
is_active = True
print(is_active)
