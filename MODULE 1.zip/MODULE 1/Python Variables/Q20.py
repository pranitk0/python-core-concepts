#Concatenate string variables.
first_name = "Pranit"
last_name = "Kamble"

full_name = first_name + " " + last_name
print(full_name)
