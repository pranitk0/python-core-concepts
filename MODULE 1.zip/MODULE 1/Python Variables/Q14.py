#Print type of a variable using type().

x = 10
print(type(x))
