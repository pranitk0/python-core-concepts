# Adding integer and float
num1 = 10      
num2 = 5.5     

result = num1 + num2
print(result)
