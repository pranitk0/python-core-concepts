# Rounding off 3.14159 to 2 decimal places
num = 3.14159
rounded_num = round(num, 2)
print(rounded_num)
