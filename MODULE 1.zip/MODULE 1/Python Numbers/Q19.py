# Check if a number is even or odd
num = 7
if num % 2 == 0:
    print("Even")
else:
    print("Odd")
