# Finding absolute value of -25
num = -25
absolute_value = abs(num)
print(absolute_value)
