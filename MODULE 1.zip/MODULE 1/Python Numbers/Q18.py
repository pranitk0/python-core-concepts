# Finding average of 5 numbers
num1 = 10
num2 = 20
num3 = 30
num4 = 40
num5 = 50

average = (num1 + num2 + num3 + num4 + num5) / 5
print(average)
