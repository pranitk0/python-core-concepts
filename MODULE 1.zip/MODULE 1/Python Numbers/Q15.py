# Finding the largest of 4 numbers
num1 = 10
num2 = 5
num3 = 20
num4 = 7

largest = max(num1, num2, num3, num4)
print(largest)
