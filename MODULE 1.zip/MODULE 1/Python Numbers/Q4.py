# Multiplying two numbers
num1 = 10
num2 = 5
product = num1 * num2
print(product)
