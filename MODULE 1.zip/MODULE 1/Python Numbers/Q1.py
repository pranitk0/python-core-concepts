#Store your age in a variable and print it.
age = 20
print(age)