#Subtract two numbers.
# Subtracting two numbers
num1 = 10
num2 = 5
sub = num1 - num2
print(sub)
