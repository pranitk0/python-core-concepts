# Converting integer to float
num = 10
num_float = float(num)
print(num_float)
