# Storing marks in 3 subjects
marks1 = 85
marks2 = 90
marks3 = 75

total = marks1 + marks2 + marks3
print(total)
