# Floor division of 17 divided by 5
result = 17 // 5
print(result)
