#Add two numbers.
# Adding two numbers
num1 = 10
num2 = 5
sum = num1 + num2
print(sum)
