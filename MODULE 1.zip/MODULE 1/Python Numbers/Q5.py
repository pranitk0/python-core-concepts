# Dividing two numbers
num1 = 10
num2 = 5
result = num1 / num2
print(result)
