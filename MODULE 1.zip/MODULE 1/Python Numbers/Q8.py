# Finding power: 2 raised to 3
result = 2 ** 3
print(result)
