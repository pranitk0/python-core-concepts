# Finding the smallest of 4 numbers
num1 = 10
num2 = 5
num3 = 20
num4 = 7

smallest = min(num1, num2, num3, num4)
print(smallest)
