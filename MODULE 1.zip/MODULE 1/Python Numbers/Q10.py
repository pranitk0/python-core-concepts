# Converting float to integer
num = 9.8
num_int = int(num)
print(num_int)
