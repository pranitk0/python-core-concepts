# Finding square root using exponent operator
num = 16
sqrt = num ** 0.5
print(sqrt)
