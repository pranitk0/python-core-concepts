# Finding remainder of 17 divided by 5
remainder = 17 % 5
print(remainder)
