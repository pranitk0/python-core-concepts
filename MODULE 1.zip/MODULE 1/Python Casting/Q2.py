#Convert float 9.9 into integer.
num = 9.9
num_int = int(num)
print(num_int)
