num = 99
complex_num = complex(num)
print(complex_num)
print(type(complex_num))
