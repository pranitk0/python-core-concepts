num = 123
num_str = str(num)
print(num_str)
print(type(num_str))
