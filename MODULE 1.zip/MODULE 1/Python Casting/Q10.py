num_str = "100"
num_float = float(num_str)
print(num_float)
print(type(num_float))
