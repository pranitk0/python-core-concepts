num = 0
bool_val = bool(num)
print(bool_val)
print(type(bool_val))
