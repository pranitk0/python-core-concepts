bool_val = False
str_val = str(bool_val)
print(str_val)
print(type(str_val))
