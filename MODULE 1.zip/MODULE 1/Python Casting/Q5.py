num_str = "3.14"
num_float = float(num_str)
print(num_float)
print(type(num_float))
