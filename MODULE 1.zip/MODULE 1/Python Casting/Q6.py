bool_val = True
int_val = int(bool_val)
print(int_val)
print(type(int_val))
