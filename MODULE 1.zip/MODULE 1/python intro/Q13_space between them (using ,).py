print("Hello", "World")
