print("orange")
