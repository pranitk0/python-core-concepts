print("Ratnagiri, India")
