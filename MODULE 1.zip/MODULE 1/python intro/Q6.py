print("I am learning Python\n"*3)
