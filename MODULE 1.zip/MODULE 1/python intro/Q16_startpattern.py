print("* * *")
