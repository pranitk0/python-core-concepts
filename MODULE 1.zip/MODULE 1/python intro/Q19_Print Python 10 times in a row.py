print("Python" * 10)
