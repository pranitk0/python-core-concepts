print("Line 1\nLine 2\nLine 3\nLine 4\nLine 5")
