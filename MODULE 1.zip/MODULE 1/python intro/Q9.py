print("Python is easy")
