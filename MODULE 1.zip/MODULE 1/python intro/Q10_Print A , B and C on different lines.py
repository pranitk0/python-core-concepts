print("A\nB\nC")
