print("Believe in yourself")
