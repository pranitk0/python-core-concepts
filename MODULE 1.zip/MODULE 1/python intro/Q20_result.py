print(10 / 2)
