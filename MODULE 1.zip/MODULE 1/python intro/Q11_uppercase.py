print("Pranit".upper())
