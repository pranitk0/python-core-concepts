print("Name: Pranit\nRoll No: 1")
