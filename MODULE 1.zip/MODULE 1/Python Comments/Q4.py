#Create a program with no output but only comments.
#Create a program with no output but only comments.
#Create a program with no output but only comments.
#Create a program with no output but only comments.