#Add comments explaining your name and age in a program.

# Printing my name
print("Pranit")

# Printing my age
print("20")
