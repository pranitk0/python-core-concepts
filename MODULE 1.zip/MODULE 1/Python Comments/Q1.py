# This is a single-line comment
print("Hello Python")
