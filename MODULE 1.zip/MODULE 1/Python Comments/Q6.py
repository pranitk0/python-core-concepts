#Use multi-line comments to describe your program.

"""
This program demonstrates the use of multi-line comments in Python.
It prints a greeting message to the user.
All text inside triple quotes is ignored by Python.
"""

print("Hello, welcome to the program!")
