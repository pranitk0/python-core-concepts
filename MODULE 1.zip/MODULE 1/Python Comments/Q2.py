#Write a program with 3 comments and 2 print statements.
#Write a program with 3 comments and 2 print statements.
#Write a program with 3 comments and 2 print statements.

print("name:pranit")
print("age:20")