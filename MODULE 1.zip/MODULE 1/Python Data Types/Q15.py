#Print length of a string.
text = "Python"
print(len(text))
