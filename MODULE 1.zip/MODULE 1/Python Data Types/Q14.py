#Create a dictionary with name and age.

person = {"name": "Pranit", "age": 20}
print(person)
