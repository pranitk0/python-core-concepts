#Create a variable with value None.

my_var = None
print(my_var)
print(type(my_var))
