#Convert a string number into an integer.

num_str = "100"
num_int = int(num_str)
print(num_int)
print(type(num_int))
