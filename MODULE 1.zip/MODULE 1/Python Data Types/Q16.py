#Check whether 10.5 is a float or int.
num = 10.5
print(type(num))  
