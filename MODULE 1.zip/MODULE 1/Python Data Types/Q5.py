#Store a number as a string and print its type.
num_str = "100"
print(type(num_str))
