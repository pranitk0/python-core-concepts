#Print the type of (1,2,3).

print(type((1, 2, 3)))
