#Create a boolean variable (True/False).

is_logged_in = True
has_permission = False

print(is_logged_in)
print(has_permission)
