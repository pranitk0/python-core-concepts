#Create a set with 4 unique items.

my_set = {1, 2, 3, 4}
print(my_set)
