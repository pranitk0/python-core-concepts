#Create a tuple with 3 items.

my_tuple = (10, 20, 30)
print(my_tuple)
