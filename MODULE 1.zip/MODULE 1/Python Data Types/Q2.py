#Create an integer variable and print its type.
number = 25
print(type(number))
