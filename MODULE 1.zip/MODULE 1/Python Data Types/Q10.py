#Store your name in a string and check type.

name = "Pranit"
print(name)
print(type(name))
