#Create a float variable and print its type.

value = 3.14
print(type(value))
