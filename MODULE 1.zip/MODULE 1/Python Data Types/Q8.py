#Check type of "123" and 123.
print(type("123"))  # string
print(type(123))    # integer
