#Create a string variable and print its type.

text = "Hello Python"
print(type(text))
