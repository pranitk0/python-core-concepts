#Create a complex number in Python.

z = 3 + 4j
print(z)
print(type(z))
