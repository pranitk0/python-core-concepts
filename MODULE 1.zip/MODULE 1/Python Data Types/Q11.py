#Create a list of 5 numbers.

numbers = [1, 2, 3, 4, 5]
print(numbers)
