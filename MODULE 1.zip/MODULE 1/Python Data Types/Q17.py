#Add a boolean to a list.

my_list = [1, 2, 3]

my_list.append(True)
print(my_list)
