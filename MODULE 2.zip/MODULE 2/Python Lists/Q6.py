#Change second element in list.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
fruits[1] = "Pineapple"
print(fruits)