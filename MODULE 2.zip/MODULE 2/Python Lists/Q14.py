#Sort a list of numbers.
numbers = [5, 2, 9, 1, 7]
numbers.sort()
print(numbers)
