# Find the index of "Mango"
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
index_mango = fruits.index("Mango")
print(index_mango)
