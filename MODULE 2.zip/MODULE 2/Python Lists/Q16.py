#Copy a list.
fruits = ["Apple", "Banana", "Mango"]
fruits_copy = fruits.copy()
print(fruits_copy)
