#Remove item by index using pop().
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
removed_item = fruits.pop(2)
print(removed_item)
print(fruits)