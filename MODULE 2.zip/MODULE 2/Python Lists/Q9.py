#Remove an item from list.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]

fruits.remove("Grapes")
print(fruits)
