#Print first element of a list.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
print(fruits[0])
