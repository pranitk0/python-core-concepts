#Reverse a list.
numbers = [1, 2, 3, 4, 5]
numbers.reverse()
print(numbers)
