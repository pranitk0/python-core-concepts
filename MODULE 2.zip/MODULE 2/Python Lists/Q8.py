fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
fruits.insert(2, "Pineapple")
print(fruits)
