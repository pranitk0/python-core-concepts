#Slice first 3 elements.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
print(fruits[0:3])