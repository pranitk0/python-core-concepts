#Delete list item using del.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
del fruits[1]
print(fruits)
