#Print last element of a list.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
print(fruits[4])