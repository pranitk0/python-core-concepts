#Loop through list using for.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]

for fruit in fruits:
    print(fruit)
