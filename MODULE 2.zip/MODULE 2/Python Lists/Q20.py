# Nested list
nested_list = [
    [1, 2, 3],
    ["Apple", "Banana", "Mango"],
    [True, False]
]
item = nested_list[0][0]
print(item)
