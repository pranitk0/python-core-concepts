#Print length of a list.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
print(len(fruits))