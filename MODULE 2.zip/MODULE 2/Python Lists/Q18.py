# Count occurrences of "Banana"
fruits = ["Apple", "Banana", "Mango", "Banana", "Orange", "Banana"]
count_banana = fruits.count("Banana")
print(count_banana)
