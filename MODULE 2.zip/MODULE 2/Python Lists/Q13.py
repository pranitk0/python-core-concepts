#Check if "apple" is in list.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
print("Apple" in fruits)
