#Join two lists.
list1 = [1, 2, 3]
list2 = [4, 5, 6]
joined_list = list1 + list2
print(joined_list)
