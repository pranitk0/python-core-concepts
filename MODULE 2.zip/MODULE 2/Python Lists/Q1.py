#Create a list of 5 fruits.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
print(fruits)
