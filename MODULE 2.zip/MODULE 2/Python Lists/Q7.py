#Add new item to end of list.
fruits = ["Apple", "Banana", "Mango", "Orange", "Grapes"]
fruits.append("pineapple")
print(fruits)