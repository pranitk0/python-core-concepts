#Subtract two numbers using -.
a = 22
b = 12
sub = a - b
print(sub)