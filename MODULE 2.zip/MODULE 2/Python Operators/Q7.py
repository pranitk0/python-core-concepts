#Use exponent ** for 23.
result = 2 ** 3
print(result)
