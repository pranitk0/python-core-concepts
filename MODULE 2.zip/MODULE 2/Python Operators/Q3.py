a = 10
b = 5
product = a * b
print(product)
