#Add two numbers using +.
a = 10
b = 5
sum = a + b
print(sum)
