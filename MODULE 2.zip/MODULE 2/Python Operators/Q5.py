#Use floor division //.
a = 10
b = 3
result = a // b
print(result)
