a = 10
b = 5
quotient = a / b
print(quotient)
