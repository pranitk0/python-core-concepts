a = 10
b = 3
remainder = a % b
print(remainder)
