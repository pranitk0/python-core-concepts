#Check if number is even using %.

number = 10
even = (number % 2 == 0)
print(even)
