#Use assignment operator += to add 5 to a number.
number = 10
number += 10
print(number)
