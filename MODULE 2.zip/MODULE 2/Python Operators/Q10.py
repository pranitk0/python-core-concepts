#Use *= to multiply a number by 10.

a = 10
a *= 2 
print(a)
