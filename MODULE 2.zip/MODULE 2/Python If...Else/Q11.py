#Check if a string equals "Python".

text = input("Enter a string: ")
if text == "Python":
    print("The string is 'Python'.")
else:
    print("The string is not 'Python'.")
