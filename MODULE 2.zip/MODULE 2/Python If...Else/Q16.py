#Print "Teenager" if age between 13–19.
age = int(input("Enter age: "))
if 13 <= age <= 19:
    print("Teenager")
