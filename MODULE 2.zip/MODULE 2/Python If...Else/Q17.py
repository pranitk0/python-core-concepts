#Print "Senior Citizen" if age ≥ 60.
age = int(input("Enter age: "))
if age >= 60:
    print("Senior Citizen")
