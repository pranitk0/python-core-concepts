#Check if a number is greater than 10 and less than 20.

num = float(input("Enter a number: "))
if 10 < num < 20:
    print("The number is greater than 10 and less than 20.")
else:
    print("The number is not in the range 10 to 20.")
