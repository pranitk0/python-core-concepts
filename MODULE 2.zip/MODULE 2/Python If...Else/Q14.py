#Print "Weekend" if day is Saturday or Sunday, else "Weekday".
day = input("Enter the day: ")
if day == "Saturday" or day == "Sunday":
    print("Weekend")
else:
    print("Weekday")
