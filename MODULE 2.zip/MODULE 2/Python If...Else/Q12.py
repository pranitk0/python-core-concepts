#13. Print "Yes" if "a" is in "apple".

if "a" in "apple":
    print("Yes")
