#Print "Even" if a number is even, else "Odd".

num = int(input("Enter a number: "))
if num % 2 == 0:
    print("Even")
else:
    print("Odd")
