# Print "Adult" or "Child"
age = int(input("Enter your age: "))
print("Adult" if age >= 18 else "Child")
