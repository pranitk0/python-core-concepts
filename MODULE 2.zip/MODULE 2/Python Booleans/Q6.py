print("A" < "B")
