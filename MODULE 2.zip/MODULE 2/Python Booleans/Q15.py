#Use not operator on True.
print(not True)
