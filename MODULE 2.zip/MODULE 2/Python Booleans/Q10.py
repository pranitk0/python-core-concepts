#Use bool("") and print result.
result = bool("")
print(result)
