#Compare 10 >= 10.
print(10 >= 10)
