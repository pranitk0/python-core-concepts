#Check if 10 != 5.
print(10!=5)