#Check if 2 + 2 == 4.
print(2 + 2 == 4)
