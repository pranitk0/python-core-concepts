#Check if "Python" == "python".
print("Python" == "python")
