#Use bool("Hello") and print result.
result = bool("Hello")
print(result)
