#Use and with two conditions.
print(10 > 5 and 8 < 20)
