result=bool(0)
print(result)