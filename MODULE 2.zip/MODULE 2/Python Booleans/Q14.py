#Use or with two conditions.
print(10 < 5 or 8 < 20)
