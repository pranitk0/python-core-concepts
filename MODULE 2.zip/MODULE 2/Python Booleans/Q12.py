#Check if 5 in [1,2,3,4,5].
print(5 in [1, 2, 3, 4, 5])

