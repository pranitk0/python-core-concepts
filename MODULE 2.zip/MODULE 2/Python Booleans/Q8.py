#Store a comparison in variable and print it.
result = 10 > 5
print(result)
