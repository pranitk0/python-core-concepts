#Check if 5 < 2 or 2 < 5.
print(5 < 2 or 2 < 5)
