#Print value of True and False.

print(True)
print(False)
