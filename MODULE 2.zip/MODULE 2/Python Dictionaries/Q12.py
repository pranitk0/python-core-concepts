person = {
    "name": "pranit",
    "age": 23
}

for items in person.items():
    print(items)
