#Remove item using pop().
person = {
    "name": "pranit",
    "age": 23
}

removed_value = person.pop("age")
print(person)