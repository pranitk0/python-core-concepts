#Remove last item using popitem().
person = {
    "name": "pranit",
    "age": 23
}
last_item = person.popitem()
print(person)