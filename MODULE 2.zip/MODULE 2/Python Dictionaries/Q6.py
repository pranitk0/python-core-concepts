#Add a new key-value pair.
person = {
    "name": "pranit",
    "age": 20
}

person["city"] = "Rtn"
print(person)
