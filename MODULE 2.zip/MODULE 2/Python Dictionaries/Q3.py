#Print all keys.
person = {
    "name": "pranit",
    "age": 20
}

print(person.keys())