person = {
    "name": "pranit",
    "age": 23
}

for key in person:
    print(key)
