#Change value of existing key.
person = {
    "name": "pranit",
    "age": 23
}

person["age"] = "20"
print(person)