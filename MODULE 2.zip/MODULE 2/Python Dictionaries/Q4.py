#Print all values.
person = {
    "name": "pranit",
    "age": 20
}

print(person.values())