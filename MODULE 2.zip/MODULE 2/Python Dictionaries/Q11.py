person = {
    "name": "pranit",
    "age": 23
}

for value in person.values():
    print(value)
