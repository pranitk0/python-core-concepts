#Create dictionary with name and age.
person = {
    "name": "pranit",
    "age": 20
}

print(person)
