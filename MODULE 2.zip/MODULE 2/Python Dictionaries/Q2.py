#Print value of key "name".
person = {
    "name": "pranit",
    "age": 20
}

print(person["name"])
