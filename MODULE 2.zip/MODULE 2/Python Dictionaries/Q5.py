#Print all key-value pairs.
person = {
    "name": "pranit",
    "age": 20
}

print(person.items())