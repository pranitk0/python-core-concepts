# Loop through set.
numbers = {10, 20, 30, 40, 50}
for num in numbers:
    print(num)
