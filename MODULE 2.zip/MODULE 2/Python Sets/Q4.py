#Add new item to set.
numbers = {10, 20, 30, 40, 50}
numbers.add(60)
print(numbers)
