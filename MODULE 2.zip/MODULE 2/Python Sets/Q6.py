#Remove item using remove().
numbers = {10, 20, 30, 40, 50}
numbers.remove(30)
print(numbers)
