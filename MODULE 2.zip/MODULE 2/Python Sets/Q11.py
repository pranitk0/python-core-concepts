#Create difference of two sets.
set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}

difference_set = set1.difference(set2)
print(difference_set)