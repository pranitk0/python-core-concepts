#Create a set of 5 numbers.
numbers = {10, 20, 30, 40, 50}
print(type(numbers))
print(numbers)
