# Using issubset() method
A = {1, 2}
B = {1, 2, 3, 4}
print(A.issubset(B))