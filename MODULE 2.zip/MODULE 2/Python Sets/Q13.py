#Check if set A is superset of B.
A = {1, 2, 3, 4}
B = {2, 3}
print(A.issuperset(B))