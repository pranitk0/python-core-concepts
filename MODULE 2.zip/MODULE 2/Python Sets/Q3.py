#Check if an element exists in set.

numbers = {10, 20, 30, 40, 50}
print(20 in numbers)

print(60 in numbers)
