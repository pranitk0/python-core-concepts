#Add multiple items to set.
numbers = {10, 20, 30}
numbers.update([40, 50, 60])
print(numbers)
