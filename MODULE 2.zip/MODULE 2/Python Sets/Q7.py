#Clear all items from set.
numbers = {10, 20, 30, 40, 50}
numbers.clear()
print(numbers)
