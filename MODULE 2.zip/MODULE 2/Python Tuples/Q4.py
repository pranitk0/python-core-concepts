#Slice first 3 elements of tuple.
numbers = (10, 20, 30, 40, 50)

first_three = numbers[:3]
print(first_three)
