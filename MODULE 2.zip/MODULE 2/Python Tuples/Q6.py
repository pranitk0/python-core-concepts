#Convert tuple into list.
numbers_tuple = (10, 20, 30, 40)
numbers_list = list(numbers_tuple)
print(numbers_list)
