#Create nested tuple.
nested_tuple = (1, 2, (3, 4, 5), ("Apple", "Banana"))
print(nested_tuple)
