#Print last element of tuple.
numbers = (10, 20, 30, 40)
print(numbers[-1])
