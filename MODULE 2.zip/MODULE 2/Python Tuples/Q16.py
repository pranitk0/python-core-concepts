#Create tuple of mixed data types.
mixed_tuple = (10, "Hello", 3.14, True)
print(mixed_tuple)
