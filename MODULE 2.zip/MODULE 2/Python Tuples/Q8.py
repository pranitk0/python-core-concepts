numbers = (10, 20, 30, 40)

for num in numbers:
    print(num)
