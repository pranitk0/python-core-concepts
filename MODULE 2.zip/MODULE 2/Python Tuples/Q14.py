#Repeat tuple elements.
numbers = (1, 2, 3)

repeated = numbers * 3
print(repeated)
