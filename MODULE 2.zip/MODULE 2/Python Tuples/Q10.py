#Count how many times an item appears.
numbers = (10, 20, 30, 20, 40, 20)
count = numbers.count(20)
print(count)
