#Compare two tuples.
tuple1 = (1, 2, 3)
tuple2 = (1, 2, 4)

print(tuple1 == tuple2)
print(tuple1 < tuple2)
