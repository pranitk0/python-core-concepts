#Use tuple unpacking (a, b = (10, 20)).

a, b = (10, 20)
print("a =", a)
print("b =", b)
