#Create tuple with one item.
single_item_tuple = (10,)
print(single_item_tuple)
