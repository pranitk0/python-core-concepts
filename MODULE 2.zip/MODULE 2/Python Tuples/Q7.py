#Convert list back into tuple.
numbers_list = [10, 20, 30, 40]

numbers_tuple = tuple(numbers_list)
print(numbers_tuple)
