#Create a tuple of 4 numbers.
numbers = (10, 20, 30, 40)
print(numbers)
