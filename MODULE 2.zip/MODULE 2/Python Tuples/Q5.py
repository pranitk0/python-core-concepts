#Check if "apple" is in tuple.
fruits = ("Apple", "Banana", "Mango", "Orange")
print("Apple" in fruits)
