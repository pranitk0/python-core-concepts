#Find index of an element in tuple.
numbers = (10, 20, 30, 40, 50)

index= numbers.index(30)
print(index)
